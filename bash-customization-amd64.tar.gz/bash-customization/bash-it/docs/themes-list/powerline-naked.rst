.. _powerline_naked:

Powerline Naked Theme
=====================

A colorful theme, where shows a lot information about your shell session.
The naked powerline theme provides a cleaner shell with less background colors.

See :ref:`powerline_base` for general information about the powerline theme.
