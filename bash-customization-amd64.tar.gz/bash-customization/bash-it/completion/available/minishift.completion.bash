# shellcheck shell=bash
# shellcheck disable=SC1090
_command_exists minishift && source <(minishift completion bash)
