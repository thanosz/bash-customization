# shellcheck shell=bash
# shellcheck disable=SC1090
_command_exists oc && source <(oc completion bash)
