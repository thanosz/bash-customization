# shellcheck shell=bash
cite about-plugin
about-plugin 'Helpers to get Docker setup correctly for docker-machine'
_log_warning '"docker-machine" is now deprecated, and as such the plugin for it is also deprecated.
Please disable this plugin.'
