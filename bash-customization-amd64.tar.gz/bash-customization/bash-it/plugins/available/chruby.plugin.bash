# shellcheck shell=bash
# shellcheck disable=SC1091
cite about-plugin
about-plugin 'load chruby                  (from /usr/local/share/chruby)'

source /usr/local/share/chruby/chruby.sh
