# shellcheck shell=bash

alias test_alias="a"
