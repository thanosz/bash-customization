# shellcheck shell=bash
about-alias 'ansible abbreviations'

alias ans=ansible
alias ap=ansible-playbook
